"""Bài E4 ★★ – Tổng hợp: Phòng chiếu.
PhongChieu che giấu sơ đồ ghế; bên ngoài đặt và hủy vé qua phương thức,
dùng được len(), in, for như một kiểu có sẵn. Các lớp vé đã viết sẵn."""


class Ve:
    def __init__(self, ma_ghe, gia_goc):
        self.ma_ghe = ma_ghe
        self.gia_goc = gia_goc

    def gia(self):
        return self.gia_goc


class VeVIP(Ve):
    def gia(self):
        return self.gia_goc * 3 // 2


class PhongChieu:
    def __init__(self, ten, so_hang, so_cot):
        """Đã viết sẵn: sơ đồ ghế là dict RIÊNG TƯ {mã ghế: vé hoặc None}.
        Hàng đặt tên A, B, C…; cột đánh số từ 1. Ví dụ 3 × 5: A1…A5, B1…B5, C1…C5."""
        self.ten = ten
        self.__ghe = {}
        for h in range(so_hang):
            for c in range(1, so_cot + 1):
                self.__ghe[f"{chr(65 + h)}{c}"] = None
        self.__so_hang, self.__so_cot = so_hang, so_cot

    # TODO: property so_ghe (tổng số ghế) và so_ghe_trong (tổng số ghế - số ghế đã đặt)

    def dat(self, ve):
        """TODO: Đặt vé vào ghế ve.ma_ghe.
        Ghế không tồn tại → ValueError; ghế đã có người → ValueError."""
        pass

    def huy(self, ma_ghe):
        """TODO: Ghế chưa đặt → ValueError. Trả ghế về None và trả lại vé đã hủy."""
        pass

    # TODO: __len__: số ghế đã đặt
    # TODO: __contains__(ma_ghe): True nếu ghế đó đã có người đặt
    # TODO: __iter__: duyệt các vé đã đặt (gợi ý: return iter([...]))

    def doanh_thu(self):
        """TODO: Tổng ve.gia() của các vé đã đặt (gợi ý: for ve in self)."""
        pass

    def so_do(self):
        """TODO: Sơ đồ, mỗi hàng một dòng: 'A . X X . .' (X: đã đặt, .: trống)."""
        pass


if __name__ == "__main__":
    # Thử nghiệm của em ở đây, sau đó chạy file kiem_tra_E4.py
    p = PhongChieu("Phòng 1", 3, 5)
