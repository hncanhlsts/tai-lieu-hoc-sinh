"""Tự kiểm tra Bài E1. Đặt file này CÙNG THƯ MỤC với bai_E1.py rồi chạy (F5 trong Thonny/IDLE)."""
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def bao_loi(ham, loai=ValueError):
    try:
        ham()
    except loai:
        return True
    except Exception:  # noqa
        return False
    return False


print("KIỂM TRA BÀI E1")
from bai_E1 import *  # noqa

kiem_tra("VeVIP và VeHocSinh kế thừa Ve; VeDoi kế thừa VeVIP",
         lambda: VeVIP.__bases__ == (Ve,) and VeHocSinh.__bases__ == (Ve,) and VeDoi.__bases__ == (VeVIP,))
kiem_tra("Ve('A1', 80000).gia() == 80000", lambda: Ve("A1", 80000).gia() == 80000)
kiem_tra("str(Ve('A1', 80000)) == 'A1 [Thường] 80.000đ'", lambda: str(Ve("A1", 80000)) == "A1 [Thường] 80.000đ")
kiem_tra("VeVIP đắt hơn 50%: 80000 → 120000", lambda: VeVIP("E5", 80000).gia() == 120000)
kiem_tra("VeVIP không viết lại __str__ mà vẫn in đúng 'E5 [VIP] 120.000đ'",
         lambda: "__str__" not in VeVIP.__dict__ and str(VeVIP("E5", 80000)) == "E5 [VIP] 120.000đ")
kiem_tra("VeHocSinh gọi super().__init__: có ma_ghe, gia_goc và ma_hs",
         lambda: (lambda v: (v.ma_ghe, v.gia_goc, v.ma_hs) == ("B2", 80000, "HS0217"))(VeHocSinh("B2", 80000, "HS0217")))
kiem_tra("VeHocSinh giảm 20%: 80000 → 64000", lambda: VeHocSinh("B2", 80000, "HS0217").gia() == 64000)
kiem_tra("VeHocSinh mở rộng __str__: 'B2 [HS] 64.000đ - mã HS HS0217'",
         lambda: str(VeHocSinh("B2", 80000, "HS0217")) == "B2 [HS] 64.000đ - mã HS HS0217")
kiem_tra("VeDoi = 2 vé VIP: 80000 → 240000", lambda: VeDoi("H1", 80000).gia() == 240000)


class _VeVIPGiaMoi(VeVIP):          # đổi cách tính VIP: VeDoi phải tự đổi theo nếu dùng super()
    def gia(self):
        return self.gia_goc * 2


class _VeDoiThu(VeDoi, _VeVIPGiaMoi):
    pass


kiem_tra("VeDoi dùng super().gia() chứ không chép công thức VIP", lambda: _VeDoiThu("H1", 80000).gia() == 320000)

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
