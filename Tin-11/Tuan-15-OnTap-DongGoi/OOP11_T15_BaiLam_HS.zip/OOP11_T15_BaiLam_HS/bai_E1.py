"""Bài E1 – Ôn tập kế thừa: Vé xem phim ở rạp Ngôi Sao.
Ve là lớp cha. VeVIP, VeHocSinh kế thừa Ve; VeDoi kế thừa VeVIP (kế thừa nhiều cấp).
Giá gốc ví dụ 80000đ: Thường 80.000đ · VIP 120.000đ · HS 64.000đ · Đôi 240.000đ."""


def dinh_dang_tien(so):
    """150000 -> '150.000đ' (đã viết sẵn)"""
    return f"{so:,}đ".replace(",", ".")


class Ve:
    def __init__(self, ma_ghe, gia_goc):
        """TODO: Lưu ma_ghe, gia_goc"""
        pass

    def gia(self):
        """TODO: Vé thường: trả về gia_goc"""
        pass

    def loai(self):
        return "Thường"

    def __str__(self):
        """TODO: Ví dụ 'A1 [Thường] 80.000đ'.
        Dùng self.loai() và self.gia() để lớp con không phải viết lại __str__."""
        pass


class VeVIP(Ve):
    """TODO: Ghi đè gia(): đắt hơn 50% (gia_goc * 3 // 2); ghi đè loai(): 'VIP'.
    KHÔNG viết __str__ cho lớp này."""
    pass


class VeHocSinh(Ve):
    def __init__(self, ma_ghe, gia_goc, ma_hs):
        """TODO: Gọi super().__init__(...) rồi lưu ma_hs"""
        pass

    # TODO: gia() giảm 20% (gia_goc * 80 // 100); loai() trả về 'HS'

    # TODO: __str__ MỞ RỘNG của lớp cha: thêm ' - mã HS HS0217' vào cuối


class VeDoi(VeVIP):
    """TODO: gia() = 2 lần giá VIP, PHẢI dùng super().gia() (không chép công thức 3 // 2);
    loai() trả về 'Đôi'."""
    pass


if __name__ == "__main__":
    # Thử nghiệm của em ở đây, sau đó chạy file kiem_tra_E1.py
    pass
