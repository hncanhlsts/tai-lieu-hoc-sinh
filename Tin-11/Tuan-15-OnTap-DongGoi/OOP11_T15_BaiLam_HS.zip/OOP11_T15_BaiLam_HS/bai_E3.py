"""Bài E3 – Đóng gói: Thẻ thành viên rạp Ngôi Sao.
Dữ liệu quan trọng (điểm, lịch sử) được che giấu; bên ngoài chỉ ĐỌC qua property
và chỉ THAY ĐỔI qua phương thức có kiểm tra.
Quy ước: ten (công khai, qua property) · _sdt (một gạch: dùng nội bộ) · __diem, __lich_su (hai gạch: riêng tư)."""


class TheThanhVien:
    HANG = [(1500, "Vàng"), (500, "Bạc"), (0, "Đồng")]     # (điểm tối thiểu, hạng)

    def __init__(self, ten, sdt):
        self.ten = ten                 # dòng này gọi setter của ten, nên tên cũng được kiểm tra
        self._sdt = sdt
        # TODO: tạo self.__diem = 0 và self.__lich_su = []

    @property
    def ten(self):
        """TODO: trả về self.__ten"""
        pass

    @ten.setter
    def ten(self, gia_tri):
        """TODO: cắt khoảng trắng hai đầu (strip); rỗng thì raise ValueError; lưu vào self.__ten"""
        pass

    # TODO: property diem CHỈ ĐỌC (chỉ có @property, không có setter)

    # TODO: property hang: duyệt HANG, trả về hạng đầu tiên mà điểm >= ngưỡng

    # TODO: property sdt_an: '0912345678' -> '*******678' (chỉ hiện 3 số cuối)

    # TODO: property lich_su: trả về tuple(self.__lich_su), một BẢN SAO không sửa được

    def tich_diem(self, so_tien):
        """TODO: so_tien <= 0 → ValueError. Mỗi 10.000đ được 1 điểm (so_tien // 10000).
        Cộng điểm, thêm ('+', số điểm) vào lịch sử, trả về số điểm vừa cộng."""
        pass

    def doi_diem(self, so_diem):
        """TODO: so_diem <= 0 hoặc lớn hơn điểm hiện có → ValueError (điểm giữ nguyên).
        Trừ điểm, thêm ('-', so_diem) vào lịch sử, trả về điểm còn lại."""
        pass


if __name__ == "__main__":
    # Thử nghiệm của em ở đây, sau đó chạy file kiem_tra_E3.py
    the = TheThanhVien("  Minh Anh ", "0912345678")
