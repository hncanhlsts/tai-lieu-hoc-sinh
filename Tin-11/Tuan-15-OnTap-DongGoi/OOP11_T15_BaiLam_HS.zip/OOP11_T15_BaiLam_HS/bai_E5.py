"""Bài E5 ★★★ – Thám tử sửa lỗi.
Bạn Tùng viết các lớp dưới đây nhưng chương trình chạy sai. MỖI LỚP CÓ ĐÚNG 1 LỖI (5 lỗi).
Em tìm và sửa, ghi chú thích # SỬA: ... ở dòng đã sửa. Không xóa lớp, không đổi tên phương thức.
Mẹo: chạy kiem_tra_E5.py, đọc kĩ thông báo lỗi (RecursionError, AttributeError, …)."""


class Ve:
    def __init__(self, ma_ghe, gia_goc):
        self.ma_ghe = ma_ghe
        self.gia_goc = gia_goc

    def gia(self):
        return self.gia_goc

    def __str__(self):
        print(f"{self.ma_ghe}: {self.gia()}")


class VeVIP(Ve):
    def gia(self):
        return self.gia() * 3 // 2


class VeHocSinh(Ve):
    def __init__(self, ma_ghe, gia_goc, ma_hs):
        self.ma_hs = ma_hs

    def gia(self):
        return self.gia_goc * 80 // 100


class TheQuaTang:
    def __init__(self, so_du):
        self.so_du = so_du

    @property
    def so_du(self):
        return self._so_du

    @so_du.setter
    def so_du(self, gia_tri):
        if gia_tri < 0:
            raise ValueError("Số dư không được âm")
        self.so_du = gia_tri


class SuatChieu:
    ds_ve = []

    def __init__(self, phim):
        self.phim = phim

    def ban(self, ve):
        self.ds_ve.append(ve)
