"""Bài E2 – Ôn tập đa hình: Quầy thu ngân.
Các lớp vé đã viết sẵn (giống E1). Em viết lớp ComboBapNuoc (KHÔNG kế thừa Ve)
và 4 hàm dùng chung cho mọi thứ "có giá"."""


def dinh_dang_tien(so):
    return f"{so:,}đ".replace(",", ".")


class Ve:
    def __init__(self, ma_ghe, gia_goc):
        self.ma_ghe = ma_ghe
        self.gia_goc = gia_goc

    def gia(self):
        return self.gia_goc

    def loai(self):
        return "Thường"

    def __str__(self):
        return f"Vé {self.ma_ghe} [{self.loai()}] {dinh_dang_tien(self.gia())}"


class VeVIP(Ve):
    def gia(self):
        return self.gia_goc * 3 // 2

    def loai(self):
        return "VIP"


class VeHocSinh(Ve):
    def gia(self):
        return self.gia_goc * 80 // 100

    def loai(self):
        return "HS"


class ComboBapNuoc:
    """TODO: Combo bắp nước KHÔNG kế thừa Ve.
    __init__(ten, gia_ban); gia() trả về gia_ban;
    __str__ ví dụ 'Combo Bắp lớn + 2 nước 89.000đ'. Combo không có loai()."""
    pass


def tong_tien(ds):
    """TODO: Tổng x.gia() của mọi món trong ds (ds rỗng → 0). Không dùng isinstance."""
    pass


def dem_theo_loai(ds):
    """TODO: Trả về dict đếm số món theo x.loai(), ví dụ {'VIP': 1, 'HS': 1, 'Khác': 1}.
    Món không có loai() (như combo) tính vào 'Khác'.
    Gợi ý (EAFP): try: lay_loai = x.loai / except AttributeError: ten = 'Khác'"""
    pass


def dat_nhat(ds):
    """TODO: Trả về CHÍNH món có giá cao nhất (gợi ý: max(ds, key=...))."""
    pass


def hoa_don(ds):
    """TODO: List chuỗi: str(x) của từng món, dòng cuối 'Tổng: 353.000đ'."""
    pass


if __name__ == "__main__":
    # Thử nghiệm của em ở đây, sau đó chạy file kiem_tra_E2.py
    pass
