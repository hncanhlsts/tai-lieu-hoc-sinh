"""Tự kiểm tra Bài E2. Đặt file này CÙNG THƯ MỤC với bai_E2.py rồi chạy (F5 trong Thonny/IDLE)."""
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def bao_loi(ham, loai=ValueError):
    try:
        ham()
    except loai:
        return True
    except Exception:  # noqa
        return False
    return False


print("KIỂM TRA BÀI E2")
from bai_E2 import *  # noqa

def _don():
    return [VeVIP("E5", 80000), VeHocSinh("B2", 80000), Ve("A1", 80000), ComboBapNuoc("Bắp lớn + 2 nước", 89000)]
print("  (don = [VeVIP E5, VeHocSinh B2, Ve A1, Combo 89000], giá gốc 80000)")
kiem_tra("ComboBapNuoc KHÔNG kế thừa Ve (chỉ kế thừa object)", lambda: ComboBapNuoc.__bases__ == (object,))
kiem_tra("ComboBapNuoc('Bắp lớn + 2 nước', 89000).gia() == 89000", lambda: ComboBapNuoc("Bắp lớn + 2 nước", 89000).gia() == 89000)
kiem_tra("str(combo) == 'Combo Bắp lớn + 2 nước 89.000đ'", lambda: str(ComboBapNuoc("Bắp lớn + 2 nước", 89000)) == "Combo Bắp lớn + 2 nước 89.000đ")
kiem_tra("tong_tien(don) == 353000", lambda: tong_tien(_don()) == 353000)
kiem_tra("tong_tien([]) == 0", lambda: tong_tien([]) == 0)
kiem_tra("dem_theo_loai(don) == {'VIP': 1, 'HS': 1, 'Thường': 1, 'Khác': 1}",
         lambda: dem_theo_loai(_don()) == {"VIP": 1, "HS": 1, "Thường": 1, "Khác": 1})
kiem_tra("dat_nhat(don) trả về chính vé VIP E5", lambda: (lambda d: dat_nhat(d) is d[0])(_don()))
kiem_tra("hoa_don(don): 4 dòng món + dòng 'Tổng: 353.000đ'",
         lambda: hoa_don(_don()) == ["Vé E5 [VIP] 120.000đ", "Vé B2 [HS] 64.000đ", "Vé A1 [Thường] 80.000đ",
                                  "Combo Bắp lớn + 2 nước 89.000đ", "Tổng: 353.000đ"])


class GuiXe:                         # một lớp "lạ" chưa từng biết, chỉ cần có gia()
    def gia(self):
        return 5000

    def __str__(self):
        return "Gửi xe 5.000đ"


kiem_tra("Đa hình: các hàm nhận cả lớp mới GuiXe",
         lambda: tong_tien([GuiXe(), Ve("A1", 80000)]) == 85000 and dem_theo_loai([GuiXe()]) == {"Khác": 1}
         and hoa_don([GuiXe()])[-1] == "Tổng: 5.000đ")

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
