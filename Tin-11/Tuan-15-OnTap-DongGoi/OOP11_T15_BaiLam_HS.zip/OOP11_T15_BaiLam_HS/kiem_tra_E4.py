"""Tự kiểm tra Bài E4. Đặt file này CÙNG THƯ MỤC với bai_E4.py rồi chạy (F5 trong Thonny/IDLE)."""
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def bao_loi(ham, loai=ValueError):
    try:
        ham()
    except loai:
        return True
    except Exception:  # noqa
        return False
    return False


print("KIỂM TRA BÀI E4")
from bai_E4 import *  # noqa

def _p():
    p = PhongChieu("Phòng 1", 3, 5)
    p.dat(Ve("A2", 80000)); p.dat(VeVIP("C3", 80000)); p.dat(Ve("A3", 80000))
    return p
kiem_tra("Phòng 3 hàng × 5 cột: so_ghe == 15, chưa ai đặt: len == 0",
         lambda: (lambda p: p.so_ghe == 15 and len(p) == 0)(PhongChieu("P", 3, 5)))
kiem_tra("Đặt 3 vé: len(p) == 3, so_ghe_trong == 12", lambda: (lambda p: len(p) == 3 and p.so_ghe_trong == 12)(_p()))
kiem_tra("'C3' in p là True, 'B1' in p là False", lambda: (lambda p: "C3" in p and "B1" not in p)(_p()))
kiem_tra("Đặt trùng ghế báo ValueError", lambda: bao_loi(lambda: _p().dat(Ve("A2", 80000))))
kiem_tra("Đặt ghế không tồn tại (D1, A6) báo ValueError",
         lambda: bao_loi(lambda: _p().dat(Ve("D1", 1))) and bao_loi(lambda: _p().dat(Ve("A6", 1))))
def _huy():
    p = _p(); ve = p.huy("A2")
    return ve.ma_ghe == "A2" and "A2" not in p and len(p) == 2 and bao_loi(lambda: p.huy("A2"))
kiem_tra("huy('A2') trả lại vé, ghế trống lại; hủy lần nữa báo ValueError", _huy)
kiem_tra("for ve in p duyệt các vé đã đặt", lambda: sorted(v.ma_ghe for v in _p()) == ["A2", "A3", "C3"])
kiem_tra("doanh_thu() == 280000 (vé VIP tính 120000)", lambda: _p().doanh_thu() == 280000)
kiem_tra("so_do() vẽ đúng sơ đồ ghế", lambda: _p().so_do() == "A . X X . .\nB . . . . .\nC . . X . .")
kiem_tra("Đóng gói: không có thuộc tính công khai nào chứa sơ đồ ghế (dict)",
         lambda: not [k for k, v in vars(_p()).items() if isinstance(v, dict) and not k.startswith("_")])

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
