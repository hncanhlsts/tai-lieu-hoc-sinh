"""Tự kiểm tra Bài E3. Đặt file này CÙNG THƯ MỤC với bai_E3.py rồi chạy (F5 trong Thonny/IDLE)."""
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def bao_loi(ham, loai=ValueError):
    try:
        ham()
    except loai:
        return True
    except Exception:  # noqa
        return False
    return False


print("KIỂM TRA BÀI E3")
from bai_E3 import *  # noqa

kiem_tra("Tạo thẻ: tên được cắt khoảng trắng hai đầu", lambda: TheThanhVien("  Minh Anh ", "0912345678").ten == "Minh Anh")
kiem_tra("Tên rỗng khi tạo thẻ báo ValueError", lambda: bao_loi(lambda: TheThanhVien("   ", "0912345678")))
def _doi_ten():
    t = TheThanhVien("An", "0912345678"); t.ten = "Bình"
    return t.ten == "Bình" and bao_loi(lambda: setattr(t, "ten", ""))
kiem_tra("Đổi tên qua setter; gán tên rỗng báo ValueError", _doi_ten)
kiem_tra("Thẻ mới: diem == 0 và hang == 'Đồng'", lambda: (lambda t: t.diem == 0 and t.hang == "Đồng")(TheThanhVien("An", "0912345678")))
kiem_tra("diem chỉ đọc: gán t.diem = 9999 báo AttributeError",
         lambda: bao_loi(lambda: setattr(TheThanhVien("An", "0912345678"), "diem", 9999), AttributeError))
kiem_tra("Không đọc được t.__diem từ bên ngoài", lambda: not hasattr(TheThanhVien("An", "0912345678"), "__diem"))
def _tich():
    t = TheThanhVien("An", "0912345678")
    return t.tich_diem(1_250_000) == 125 and t.diem == 125 and bao_loi(lambda: t.tich_diem(0))
kiem_tra("tich_diem: 10.000đ = 1 điểm; số tiền ≤ 0 báo ValueError", _tich)
def _hang():
    t = TheThanhVien("An", "0912345678"); kq = []
    for tien in (4_990_000, 10_000, 9_990_000, 10_000):
        t.tich_diem(tien); kq.append(t.hang)
    return kq == ["Đồng", "Bạc", "Bạc", "Vàng"]
kiem_tra("hang tự tính theo điểm: 499 Đồng, 500 Bạc, 1499 Bạc, 1500 Vàng", _hang)
def _doi():
    t = TheThanhVien("An", "0912345678"); t.tich_diem(1_000_000)
    return t.doi_diem(30) == 70 and bao_loi(lambda: t.doi_diem(71)) and bao_loi(lambda: t.doi_diem(0)) and t.diem == 70
kiem_tra("doi_diem: trừ đúng; đổi quá số điểm hoặc ≤ 0 báo ValueError, điểm giữ nguyên", _doi)
def _ls():
    t = TheThanhVien("An", "0912345678"); t.tich_diem(500_000); t.doi_diem(20)
    ls = t.lich_su
    try:
        ls.append(("+", 999))
    except AttributeError:
        pass
    return t.lich_su == (("+", 50), ("-", 20)) and t.diem == 30
kiem_tra("lich_su trả về tuple bản sao: sửa bên ngoài không làm hỏng dữ liệu thẻ", _ls)
kiem_tra("sdt_an chỉ hiện 3 số cuối: '*******678'", lambda: TheThanhVien("An", "0912345678").sdt_an == "*******678")

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
