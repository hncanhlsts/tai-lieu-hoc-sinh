"""Tự kiểm tra Bài E5. Đặt file này CÙNG THƯ MỤC với bai_E5.py rồi chạy (F5 trong Thonny/IDLE)."""
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def bao_loi(ham, loai=ValueError):
    try:
        ham()
    except loai:
        return True
    except Exception:  # noqa
        return False
    return False


print("KIỂM TRA BÀI E5")
from bai_E5 import *  # noqa

kiem_tra("Lỗi 1 (Ve): str(Ve('A1', 80000)) == 'A1: 80000'", lambda: str(Ve("A1", 80000)) == "A1: 80000")
kiem_tra("Lỗi 2 (VeVIP): VeVIP('E5', 80000).gia() == 120000", lambda: VeVIP("E5", 80000).gia() == 120000)
kiem_tra("Lỗi 3 (VeHocSinh): có ma_ghe và gia() == 64000",
         lambda: (lambda v: v.ma_ghe == "B2" and v.gia() == 64000 and v.ma_hs == "HS01")(VeHocSinh("B2", 80000, "HS01")))
kiem_tra("Lỗi 4 (TheQuaTang): tạo thẻ 50000 và đọc so_du", lambda: TheQuaTang(50000).so_du == 50000)
def _the():
    t = TheQuaTang(50000); t.so_du = 20000
    return t.so_du == 20000 and bao_loi(lambda: setattr(t, "so_du", -1)) and bao_loi(lambda: TheQuaTang(-5))
kiem_tra("TheQuaTang: gán số dư hợp lệ được, số âm báo ValueError", _the)
def _suat():
    s1, s2 = SuatChieu("Phim A"), SuatChieu("Phim B")
    s1.ban(Ve("A1", 1)); s1.ban(Ve("A2", 1)); s2.ban(Ve("B1", 1))
    return len(s1.ds_ve) == 2 and len(s2.ds_ve) == 1
kiem_tra("Lỗi 5 (SuatChieu): vé của suất này không lẫn sang suất khác", _suat)
kiem_tra("VeVIP vẫn kế thừa Ve và in được: str(VeVIP('E5', 80000)) == 'E5: 120000'",
         lambda: issubclass(VeVIP, Ve) and str(VeVIP("E5", 80000)) == "E5: 120000")

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
