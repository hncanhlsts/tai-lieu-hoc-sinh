"""Tự kiểm tra DẠNG 4 – Lớp ThoiLuong. Đặt file này CÙNG THƯ MỤC với dang4_ThoiLuong.py rồi chạy (F5 trong Thonny/IDLE)."""
import io, contextlib
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def chay():
    """Chạy cả file bài làm, trả về những gì nó in ra (để kiểm tra phần c)."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        exec(open("dang4_ThoiLuong.py", encoding="utf-8").read(), {"__name__": "__main__"})
    return buf.getvalue().strip()


print("KIỂM TRA DẠNG 4 – Lớp ThoiLuong")
_ns = {"__name__": "bai_lam"}
try:
    with contextlib.redirect_stdout(io.StringIO()):
        exec(open("dang4_ThoiLuong.py", encoding="utf-8").read(), _ns)
except Exception as _e:  # noqa
    print(f"  ! Chương trình của em đang báo lỗi khi chạy: {type(_e).__name__}: {_e}")
globals().update({k: v for k, v in _ns.items() if not k.startswith("__")})

kiem_tra("__add__ trả về đối tượng ThoiLuong mới", lambda: isinstance(ThoiLuong(1, 0) + ThoiLuong(2, 0), ThoiLuong))
kiem_tra("1 phút 10 giây + 2 phút 20 giây = 3 phút 30 giây", lambda: (lambda t: (t.phut, t.giay) == (3, 30))(ThoiLuong(1, 10) + ThoiLuong(2, 20)))
kiem_tra("Đổi đủ 60 giây thành phút: 3:45 + 2:30 = 6 phút 15 giây", lambda: (lambda t: (t.phut, t.giay) == (6, 15))(ThoiLuong(3, 45) + ThoiLuong(2, 30)))
def _giu():
    a, b = ThoiLuong(3, 45), ThoiLuong(2, 30); c = a + b
    return (a.phut, a.giay, b.phut, b.giay) == (3, 45, 2, 30) and c is not a
kiem_tra("Phép cộng không làm thay đổi hai thời lượng ban đầu", _giu)
kiem_tra("str(ThoiLuong(6, 15)) == '6 phút 15 giây'", lambda: str(ThoiLuong(6, 15)) == "6 phút 15 giây")
kiem_tra("Chương trình in ra: 6 phút 15 giây", lambda: chay() == "6 phút 15 giây")

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
