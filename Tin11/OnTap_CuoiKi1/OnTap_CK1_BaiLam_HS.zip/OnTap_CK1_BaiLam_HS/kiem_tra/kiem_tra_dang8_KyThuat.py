"""Tự kiểm tra DẠNG 8 – Sửa lỗi lớp KyThuat. Đặt file này CÙNG THƯ MỤC với dang8_KyThuat.py rồi chạy (F5 trong Thonny/IDLE)."""
import io, contextlib
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def chay():
    """Chạy cả file bài làm, trả về những gì nó in ra (để kiểm tra phần c)."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        exec(open("dang8_KyThuat.py", encoding="utf-8").read(), {"__name__": "__main__"})
    return buf.getvalue().strip()


print("KIỂM TRA DẠNG 8 – Sửa lỗi lớp KyThuat")
_ns = {"__name__": "bai_lam"}
try:
    with contextlib.redirect_stdout(io.StringIO()):
        exec(open("dang8_KyThuat.py", encoding="utf-8").read(), _ns)
except Exception as _e:  # noqa
    print(f"  ! Chương trình của em đang báo lỗi khi chạy: {type(_e).__name__}: {_e}")
globals().update({k: v for k, v in _ns.items() if not k.startswith("__")})

kiem_tra("KyThuat vẫn kế thừa NhanVien", lambda: issubclass(KyThuat, NhanVien))
kiem_tra("Lỗi 1: gọi super().__init__ nên có ten và luong",
         lambda: (lambda k: (k.ten, k.luong) == ("Minh", 7000000))(KyThuat("Minh", 7000000, 1500000)))
kiem_tra("Lỗi 2: lưu phụ cấp vào thuộc tính self.phu_cap", lambda: KyThuat("Minh", 7000000, 1500000).phu_cap == 1500000)
kiem_tra("Lỗi 3: tinh_luong() = 7000000 + 1500000", lambda: KyThuat("Minh", 7000000, 1500000).tinh_luong() == 8500000)
kiem_tra("Chương trình in ra: Minh 8500000", lambda: chay() == "Minh 8500000")

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
