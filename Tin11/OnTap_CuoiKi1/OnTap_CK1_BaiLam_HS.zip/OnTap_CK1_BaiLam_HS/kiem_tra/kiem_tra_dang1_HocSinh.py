"""Tự kiểm tra DẠNG 1 – Lớp HocSinh. Đặt file này CÙNG THƯ MỤC với dang1_HocSinh.py rồi chạy (F5 trong Thonny/IDLE)."""
import io, contextlib
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def chay():
    """Chạy cả file bài làm, trả về những gì nó in ra (để kiểm tra phần c)."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        exec(open("dang1_HocSinh.py", encoding="utf-8").read(), {"__name__": "__main__"})
    return buf.getvalue().strip()


print("KIỂM TRA DẠNG 1 – Lớp HocSinh")
_ns = {"__name__": "bai_lam"}
try:
    with contextlib.redirect_stdout(io.StringIO()):
        exec(open("dang1_HocSinh.py", encoding="utf-8").read(), _ns)
except Exception as _e:  # noqa
    print(f"  ! Chương trình của em đang báo lỗi khi chạy: {type(_e).__name__}: {_e}")
globals().update({k: v for k, v in _ns.items() if not k.startswith("__")})

kiem_tra("a) HocSinh('An', 9, 8) có đủ ho_ten, diem_toan, diem_van",
         lambda: (lambda h: (h.ho_ten, h.diem_toan, h.diem_van) == ("An", 9, 8))(HocSinh("An", 9, 8)))
kiem_tra("a) Mỗi đối tượng giữ thuộc tính riêng", lambda: HocSinh("A", 1, 2).ho_ten == "A" and HocSinh("B", 3, 4).ho_ten == "B")
kiem_tra("b) diem_tb() của (9, 8) là 8.5", lambda: HocSinh("An", 9, 8).diem_tb() == 8.5)
kiem_tra("b) diem_tb() TRẢ VỀ giá trị (dùng return, không print)", lambda: HocSinh("X", 7, 6).diem_tb() == 6.5)
kiem_tra("b) xep_loai(): 8 → Giỏi, 6.5 → Khá, 6 → Trung bình",
         lambda: [HocSinh("X", 8, 8).xep_loai(), HocSinh("X", 7, 6).xep_loai(), HocSinh("X", 6, 6).xep_loai()] == ["Giỏi", "Khá", "Trung bình"])
kiem_tra("c) Chương trình in ra: An 8.5 Giỏi", lambda: chay() == "An 8.5 Giỏi")

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
