"""Tự kiểm tra DẠNG 3 – Lớp SanPhamKhuyenMai. Đặt file này CÙNG THƯ MỤC với dang3_SanPhamKhuyenMai.py rồi chạy (F5 trong Thonny/IDLE)."""
import io, contextlib
DAT = 0
TONG = 0


def kiem_tra(mo_ta, ham):
    global DAT, TONG
    TONG += 1
    try:
        ok = ham()
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {type(e).__name__}: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def chay():
    """Chạy cả file bài làm, trả về những gì nó in ra (để kiểm tra phần c)."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        exec(open("dang3_SanPhamKhuyenMai.py", encoding="utf-8").read(), {"__name__": "__main__"})
    return buf.getvalue().strip()


print("KIỂM TRA DẠNG 3 – Lớp SanPhamKhuyenMai")
_ns = {"__name__": "bai_lam"}
try:
    with contextlib.redirect_stdout(io.StringIO()):
        exec(open("dang3_SanPhamKhuyenMai.py", encoding="utf-8").read(), _ns)
except Exception as _e:  # noqa
    print(f"  ! Chương trình của em đang báo lỗi khi chạy: {type(_e).__name__}: {_e}")
globals().update({k: v for k, v in _ns.items() if not k.startswith("__")})

kiem_tra("SanPhamKhuyenMai kế thừa SanPham", lambda: issubclass(SanPhamKhuyenMai, SanPham))
kiem_tra("Gọi super().__init__: có ten và gia", lambda: (lambda s: (s.ten, s.gia) == ("Chuột", 150000))(SanPhamKhuyenMai("Chuột", 150000, 20000)))
kiem_tra("Có thuộc tính mới giam", lambda: SanPhamKhuyenMai("Chuột", 150000, 20000).giam == 20000)
kiem_tra("gia_ban() = 150000 - 20000 = 130000", lambda: SanPhamKhuyenMai("Chuột", 150000, 20000).gia_ban() == 130000)
kiem_tra("Lớp SanPham vẫn đúng: gia_ban() = gia", lambda: SanPham("Bút", 5000).gia_ban() == 5000)
def _dung_super():
    class _Doi(SanPham):                 # đổi cách tính giá gốc: nếu dùng super() thì giá bán đổi theo
        def gia_ban(self):
            return self.gia * 2
    class _Thu(SanPhamKhuyenMai, _Doi):
        pass
    return _Thu("Chuột", 150000, 20000).gia_ban() == 280000
kiem_tra("Dùng super().gia_ban() (không viết lại self.gia)", _dung_super)
kiem_tra("Chương trình in ra: Chuột 130000", lambda: chay() == "Chuột 130000")

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
