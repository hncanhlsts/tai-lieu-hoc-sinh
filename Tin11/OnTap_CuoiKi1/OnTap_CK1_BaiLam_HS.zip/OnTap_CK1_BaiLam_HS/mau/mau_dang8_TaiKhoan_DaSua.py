class TaiKhoan:
    def __init__(self, chu, so_du):
        self.chu = chu
        self.so_du = so_du

    def nap(self, tien):
        self.so_du += tien

    def lay_so_du(self):
        return self.so_du

    def __str__(self):
        return f"{self.chu}: {self.so_du}"

tk = TaiKhoan("An", 100)
tk.nap(50)
print(tk)
print("Số dư:", tk.lay_so_du())
