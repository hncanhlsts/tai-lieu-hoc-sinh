class HinhHop:
    def __init__(self, dai, rong, cao):
        self.dai = dai
        self.rong = rong
        self.cao = cao

    def dien_tich_xq(self):
        return 2 * (self.dai + self.rong) * self.cao

    def the_tich(self):
        return self.dai * self.rong * self.cao

hop = HinhHop(5, 4, 3)
print("Diện tích xung quanh:", hop.dien_tich_xq())
print("Thể tích:", hop.the_tich())
