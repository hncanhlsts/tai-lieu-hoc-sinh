class HocSinh:
    def __init__(self, ten, diem):
        self.ten = ten
        self.diem = diem

    def mo_ta(self):
        return f"{self.ten}: {self.diem} điểm"

class HocSinhGioi(HocSinh):
    def __init__(self, ten, diem, giai_thuong):
        super().__init__(ten, diem)
        self.giai_thuong = giai_thuong

    def mo_ta(self):
        return super().mo_ta() + " - " + self.giai_thuong

lan = HocSinhGioi("Lan", 9.5, "Giải Nhất Tin học")
print(lan.mo_ta())
