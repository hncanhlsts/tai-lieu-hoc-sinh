class PhanSo:
    def __init__(self, tu, mau):
        self.tu = tu
        self.mau = mau

    def __add__(self, other):
        tu = self.tu * other.mau + other.tu * self.mau
        mau = self.mau * other.mau
        return PhanSo(tu, mau)

    def __str__(self):
        return f"{self.tu}/{self.mau}"

print(PhanSo(1, 2) + PhanSo(1, 3))
