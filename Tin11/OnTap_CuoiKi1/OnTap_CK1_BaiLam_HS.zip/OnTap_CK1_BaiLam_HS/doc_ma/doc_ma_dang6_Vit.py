# Hãy ĐOÁN kết quả và viết vào vở TRƯỚC khi chạy file này.

class Vit:
    def keu(self):
        return "Quạc"

class Robot:
    def keu(self):
        return "Bíp"

class Meo:
    def meo(self):
        return "Meo"

def cho_keu(x):
    return x.keu()

print(cho_keu(Vit()), cho_keu(Robot()))
print(cho_keu(Meo()))
