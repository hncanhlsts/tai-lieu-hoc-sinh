# Hãy ĐOÁN kết quả và viết vào vở TRƯỚC khi chạy file này.

class XeBuyt:
    so_ghe = 30

    def __init__(self, bien_so):
        self.bien_so = bien_so

xe1 = XeBuyt("29B-001")
xe2 = XeBuyt("29B-002")
xe1.so_ghe = 45
XeBuyt.so_ghe = 35
print(xe1.so_ghe, xe2.so_ghe, XeBuyt.so_ghe)
