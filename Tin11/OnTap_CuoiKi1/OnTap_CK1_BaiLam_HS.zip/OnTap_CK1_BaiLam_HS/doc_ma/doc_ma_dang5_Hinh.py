# Hãy ĐOÁN kết quả và viết vào vở TRƯỚC khi chạy file này.

class Hinh:
    def __init__(self, ten):
        self.ten = ten

    def dien_tich(self):
        return 0

    def mo_ta(self):
        return self.ten + " = " + str(self.dien_tich())

class Vuong(Hinh):
    def __init__(self, a):
        super().__init__("Vuông")
        self.a = a

    def dien_tich(self):
        return self.a * self.a

class ChuNhat(Hinh):
    def __init__(self, d, r):
        super().__init__("Chữ nhật")
        self.d = d
        self.r = r

    def dien_tich(self):
        return self.d * self.r

ds = [Vuong(3), ChuNhat(2, 5), Hinh("Hình")]
tong = 0
for h in ds:
    tong += h.dien_tich()
print(ds[1].mo_ta(), tong)
