"""Đoạn mã dưới đây có 3 lỗi. Em tìm, sửa và ghi chú # SỬA ở dòng đã sửa.
Kết quả đúng phải in ra: Minh 8500000"""

class NhanVien:
    def __init__(self, ten, luong):
        self.ten = ten
        self.luong = luong

    def tinh_luong(self):
        return self.luong

class KyThuat(NhanVien):
    def __init__(self, ten, luong, phu_cap):
        phu_cap = phu_cap

    def tinh_luong(self):
        return super().tinh_luong() + phu_cap

kt = KyThuat("Minh", 7000000, 1500000)
print(kt.ten, kt.tinh_luong())
