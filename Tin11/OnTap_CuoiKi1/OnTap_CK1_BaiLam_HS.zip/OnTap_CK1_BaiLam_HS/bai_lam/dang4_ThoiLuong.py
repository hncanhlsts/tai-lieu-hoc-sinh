class ThoiLuong:
    def __init__(self, phut, giay):
        self.phut = phut
        self.giay = giay

    def __add__(self, other):
        """TODO: Cộng hai thời lượng, đổi 60 giây thành 1 phút. Trả về một ThoiLuong MỚI."""
        pass

    def __str__(self):
        """TODO: Trả về chuỗi dạng "6 phút 15 giây" (dùng return, không print)."""
        pass

bai1 = ThoiLuong(3, 45)
bai2 = ThoiLuong(2, 30)
print(bai1 + bai2)
