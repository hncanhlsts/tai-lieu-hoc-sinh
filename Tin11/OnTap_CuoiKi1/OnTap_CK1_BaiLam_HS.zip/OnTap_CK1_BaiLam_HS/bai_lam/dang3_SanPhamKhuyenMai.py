class SanPham:
    def __init__(self, ten, gia):
        self.ten = ten
        self.gia = gia

    def gia_ban(self):
        return self.gia


class SanPhamKhuyenMai(SanPham):
    """TODO: Kế thừa SanPham.
    - __init__(self, ten, gia, giam): gọi super().__init__(ten, gia) rồi gán self.giam
    - Ghi đè gia_ban(): trả về super().gia_ban() - self.giam"""
    pass


# TODO: Tạo chuột "Chuột" giá 150000, giảm 20000; in tên và giá bán
