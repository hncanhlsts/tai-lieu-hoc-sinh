class HocSinh:
    def __init__(self, ho_ten, diem_toan, diem_van):
        """TODO a) Gán ba thuộc tính ho_ten, diem_toan, diem_van"""
        pass

    def diem_tb(self):
        """TODO b) Trả về điểm trung bình của Toán và Văn"""
        pass

    def xep_loai(self):
        """TODO b) Trả về "Giỏi" nếu điểm TB >= 8, "Khá" nếu >= 6.5, còn lại "Trung bình"."""
        pass


# TODO c) Tạo học sinh An có điểm Toán 9, Văn 8 rồi in: họ tên, điểm TB, xếp loại
