"""Bài 6 – Nhập an toàn và so sánh với trung bình (TỔNG HỢP)
Nhập số phần tử n; nếu người dùng nhập chữ thì in "Nhập sai, mời nhập lại" và cho nhập lại (while True + try except).
Nhập n số nguyên vào danh sách. In "Trung bình: ..." (làm tròn 2 chữ số) và "Lớn hơn trung bình: ..." (số phần tử lớn hơn trung bình).
Làm xong, chạy file kiem_tra_6.py để tự kiểm tra."""
# TODO: while True + try except để nhập n an toàn

ds = []
# TODO: nhập n số vào ds; tính tb; đếm số lớn hơn tb; in kết quả
