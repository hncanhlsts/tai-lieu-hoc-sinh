"""Bài 5 – Thêm phần tử và thống kê danh sách (TỰ VIẾT)
Cho ds = [6, 11, 3, 8, 15]. Thêm số 4 vào cuối danh sách, in danh sách.
Dùng MỘT vòng lặp for để đếm số phần tử chẵn và tính tổng các phần tử lẻ (không dùng sum).
In "Số chẵn: ..." và "Tổng số lẻ: ...". Làm xong, chạy file kiem_tra_5.py để tự kiểm tra."""
ds = [6, 11, 3, 8, 15]
# TODO: thêm 4 vào cuối, in ds

dem_chan = 0
tong_le = 0
# TODO: duyệt ds bằng for, đếm số chẵn và cộng các số lẻ

print("Số chẵn:", dem_chan)
print("Tổng số lẻ:", tong_le)
