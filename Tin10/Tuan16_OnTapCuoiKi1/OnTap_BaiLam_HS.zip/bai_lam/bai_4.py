"""Bài 4 – Cộng dồn đến khi vượt 100 (TỰ VIẾT)
Dùng while True để cộng lần lượt 1 + 2 + 3 + ... và dừng (break) ngay khi tổng LỚN HƠN 100.
In 2 dòng: "Cộng đến k" (k là số cuối cùng được cộng) và "Tổng = ...".
Làm xong, chạy file kiem_tra_4.py để tự kiểm tra."""
tong = 0
so = 0
# TODO: while True: tăng so thêm 1, cộng so vào tong, nếu tong > 100 thì break

# TODO: in 2 dòng kết quả
