"""Bài 2 – Giá vé xem phim theo tuổi (TỰ VIẾT)
Nhập tuổi (số nguyên). Dưới 6 tuổi: in "Miễn phí"; từ 6 đến dưới 18: "Giá vé: 50000";
từ 18 đến dưới 60: "Giá vé: 80000"; từ 60 tuổi trở lên: "Giá vé: 40000".
Làm xong, chạy file kiem_tra_2.py để tự kiểm tra."""
# TODO: nhập tuổi (nhớ ép kiểu int), dùng if - elif - else để in giá vé
