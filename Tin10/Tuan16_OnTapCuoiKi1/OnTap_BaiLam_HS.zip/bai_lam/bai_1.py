"""Bài 1 – Phân loại nhiệt độ (ĐIỀN VÀO CHỖ TRỐNG)
Dưới 15 độ: "Lạnh"; từ 15 đến dưới 25: "Mát"; từ 25 đến dưới 32: "Ấm"; từ 32 trở lên: "Nóng".
Nhiệt độ có thể là số thực (ví dụ 24.5). Thay mỗi ____ bằng nội dung đúng rồi chạy kiem_tra_1.py."""
t = ____(input("Nhiệt độ: "))
if t < 15:
    print("Lạnh")
elif t ____ 25:
    print("Mát")
____ t < 32:
    print("Ấm")
____:
    print("Nóng")
