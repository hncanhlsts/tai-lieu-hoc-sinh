"""Bài 3 – In dãy số với continue và break (TỰ VIẾT)
Dùng vòng lặp for in các số nguyên từ 1 đến 40 trên CÙNG MỘT DÒNG, thỏa mãn:
bỏ qua các số chia hết cho 4 (dùng continue) và dừng hẳn vòng lặp khi gặp số lớn hơn 25 (dùng break).
Làm xong, chạy file kiem_tra_3.py để tự kiểm tra."""
# TODO: for i in range(...):
#           nếu i > 25 thì break; nếu i chia hết cho 4 thì continue; còn lại in i (end=" ")
