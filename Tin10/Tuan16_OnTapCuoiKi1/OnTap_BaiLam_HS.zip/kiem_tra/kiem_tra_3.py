"""Tự kiểm tra Bài 3. Đặt file này CÙNG THƯ MỤC với bai_3.py rồi chạy (F5 trong Thonny/IDLE)."""
import os, re, subprocess, sys

FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bai_3.py")
DAT = 0
TONG = 0


def chay(du_lieu):
    """Chạy bai_3.py với dữ liệu nhập cho trước, trả về phần in ra màn hình."""
    kq = subprocess.run([sys.executable, FILE], input=du_lieu, capture_output=True,
                        text=True, encoding="utf-8", timeout=2,
                        env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    if kq.returncode != 0:
        dong_cuoi = kq.stderr.strip().splitlines()[-1] if kq.stderr.strip() else "lỗi"
        if "EOFError" in dong_cuoi:
            dong_cuoi = "chương trình đòi nhập nhiều hơn số lần cần thiết"
        raise RuntimeError(dong_cuoi)
    return kq.stdout


def cac_so(van_ban):
    """Các số nguyên xuất hiện trong văn bản (bỏ dấu phân cách hàng nghìn)."""
    van_ban = re.sub(r"(?<=\d)[.,_](?=\d{3}\b)", "", van_ban)
    return [int(x) for x in re.findall(r"-?\d+", van_ban)]


def kiem_tra(mo_ta, du_lieu, dieu_kien):
    global DAT, TONG
    TONG += 1
    try:
        ok = dieu_kien(chay(du_lieu))
    except subprocess.TimeoutExpired:
        print(f"  ✗ {mo_ta}  →  chạy quá 2 giây: có thể bị LẶP VÔ TẬN (biến điều kiện có được cập nhật không?)")
        return
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def ma_lenh():
    """Mã lệnh của bài làm, đã bỏ đề bài trong ba dấu nháy và các chú thích #."""
    van_ban = re.sub(r'"""[\s\S]*?"""', "", open(FILE, encoding="utf-8").read())
    return "\n".join(dong.split("#")[0] for dong in van_ban.splitlines())


print("KIỂM TRA BÀI 3")

DUNG = [1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 14, 15, 17, 18, 19, 21, 22, 23, 25]
kiem_tra("In đúng dãy số trên một dòng", "", lambda o: cac_so(o) == DUNG and len(o.strip().splitlines()) == 1)
kiem_tra("Không in số nào chia hết cho 4", "", lambda o: all(x % 4 for x in cac_so(o)) and len(cac_so(o)) > 0)
kiem_tra("Dừng sau số 25 (không in số lớn hơn 25)", "", lambda o: cac_so(o) and max(cac_so(o)) == 25)
kiem_tra("Dùng for, continue và break", "", lambda o: all(t in ma_lenh() for t in ("for ", "continue", "break")))

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
