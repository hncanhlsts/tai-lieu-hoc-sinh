"""Tự kiểm tra Bài 2. Đặt file này CÙNG THƯ MỤC với bai_2.py rồi chạy (F5 trong Thonny/IDLE)."""
import os, re, subprocess, sys

FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bai_2.py")
DAT = 0
TONG = 0


def chay(du_lieu):
    """Chạy bai_2.py với dữ liệu nhập cho trước, trả về phần in ra màn hình."""
    kq = subprocess.run([sys.executable, FILE], input=du_lieu, capture_output=True,
                        text=True, encoding="utf-8", timeout=2,
                        env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    if kq.returncode != 0:
        dong_cuoi = kq.stderr.strip().splitlines()[-1] if kq.stderr.strip() else "lỗi"
        if "EOFError" in dong_cuoi:
            dong_cuoi = "chương trình đòi nhập nhiều hơn số lần cần thiết"
        raise RuntimeError(dong_cuoi)
    return kq.stdout


def cac_so(van_ban):
    """Các số nguyên xuất hiện trong văn bản (bỏ dấu phân cách hàng nghìn)."""
    van_ban = re.sub(r"(?<=\d)[.,_](?=\d{3}\b)", "", van_ban)
    return [int(x) for x in re.findall(r"-?\d+", van_ban)]


def kiem_tra(mo_ta, du_lieu, dieu_kien):
    global DAT, TONG
    TONG += 1
    try:
        ok = dieu_kien(chay(du_lieu))
    except subprocess.TimeoutExpired:
        print(f"  ✗ {mo_ta}  →  chạy quá 2 giây: có thể bị LẶP VÔ TẬN (biến điều kiện có được cập nhật không?)")
        return
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def ma_lenh():
    """Mã lệnh của bài làm, đã bỏ đề bài trong ba dấu nháy và các chú thích #."""
    van_ban = re.sub(r'"""[\s\S]*?"""', "", open(FILE, encoding="utf-8").read())
    return "\n".join(dong.split("#")[0] for dong in van_ban.splitlines())


print("KIỂM TRA BÀI 2")

kiem_tra("Tuổi 5 → Miễn phí; tuổi 6 → 50000", "5\n", lambda o: "Miễn phí" in o and "50000" in chay("6\n"))
kiem_tra("Tuổi 17 → 50000; tuổi 18 → 80000", "17\n", lambda o: "50000" in o and "80000" in chay("18\n"))
kiem_tra("Tuổi 59 → 80000", "59\n", lambda o: "80000" in o and "40000" not in o)
kiem_tra("Tuổi 60 → 40000 (đúng mốc)", "60\n", lambda o: "40000" in o and "80000" not in o)

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
