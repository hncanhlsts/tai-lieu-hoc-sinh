"""Tự kiểm tra Bài 1. Đặt file này CÙNG THƯ MỤC với bai_1.py rồi chạy (F5 trong Thonny/IDLE)."""
import os, re, subprocess, sys

FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bai_1.py")
DAT = 0
TONG = 0


def chay(du_lieu):
    """Chạy bai_1.py với dữ liệu nhập cho trước, trả về phần in ra màn hình."""
    kq = subprocess.run([sys.executable, FILE], input=du_lieu, capture_output=True,
                        text=True, encoding="utf-8", timeout=2,
                        env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    if kq.returncode != 0:
        dong_cuoi = kq.stderr.strip().splitlines()[-1] if kq.stderr.strip() else "lỗi"
        if "EOFError" in dong_cuoi:
            dong_cuoi = "chương trình đòi nhập nhiều hơn số lần cần thiết"
        raise RuntimeError(dong_cuoi)
    return kq.stdout


def cac_so(van_ban):
    """Các số nguyên xuất hiện trong văn bản (bỏ dấu phân cách hàng nghìn)."""
    van_ban = re.sub(r"(?<=\d)[.,_](?=\d{3}\b)", "", van_ban)
    return [int(x) for x in re.findall(r"-?\d+", van_ban)]


def kiem_tra(mo_ta, du_lieu, dieu_kien):
    global DAT, TONG
    TONG += 1
    try:
        ok = dieu_kien(chay(du_lieu))
    except subprocess.TimeoutExpired:
        print(f"  ✗ {mo_ta}  →  chạy quá 2 giây: có thể bị LẶP VÔ TẬN (biến điều kiện có được cập nhật không?)")
        return
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def ma_lenh():
    """Mã lệnh của bài làm, đã bỏ đề bài trong ba dấu nháy và các chú thích #."""
    van_ban = re.sub(r'"""[\s\S]*?"""', "", open(FILE, encoding="utf-8").read())
    return "\n".join(dong.split("#")[0] for dong in van_ban.splitlines())


print("KIỂM TRA BÀI 1")

T = "7\n30\n32\n34\n29\n27\n31\n30\n"
kiem_tra("7 ngày: Cao nhất 34, Thấp nhất 27", T, lambda o: "Cao nhất: 34" in o and "Thấp nhất: 27" in o)
kiem_tra("Chênh lệch: 7", T, lambda o: "Chênh lệch: 7" in o)
kiem_tra("Trung bình làm tròn 1 chữ số: 30.4", T, lambda o: "Trung bình: 30.4" in o)
kiem_tra("Có nhiệt độ âm: -3, 5, 1 → Cao 5, Thấp -3, Chênh 8, TB 1.0", "3\n-3\n5\n1\n",
         lambda o: "Cao nhất: 5" in o and "Thấp nhất: -3" in o and "Chênh lệch: 8" in o and "Trung bình: 1.0" in o)

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
