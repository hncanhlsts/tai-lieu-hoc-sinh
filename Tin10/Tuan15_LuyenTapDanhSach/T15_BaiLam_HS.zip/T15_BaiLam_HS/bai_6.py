"""Bài 6 (★) – Số xuất hiện nhiều nhất (KHÔNG dùng ds.count)
Nhập n, rồi nhập n số nguyên. Với mỗi phần tử, dùng vòng lặp bên trong để đếm số lần nó xuất hiện.
In "Xuất hiện nhiều nhất: x (k lần)". Nếu nhiều số cùng số lần thì lấy số xuất hiện TRƯỚC trong danh sách.
Ví dụ: 5, 3, 7, 3, 5, 3 → Xuất hiện nhiều nhất: 3 (3 lần)
Làm xong, chạy file kiem_tra_6.py để tự kiểm tra."""
n = int(input("Số phần tử: "))
ds = []
for i in range(n):
    ds.append(int(input("Nhập số: ")))
so_nhieu = ds[0]
lan_nhieu = 0
# TODO: với mỗi x trong ds: đếm số phần tử bằng x bằng một vòng lặp bên trong;
#       nếu số lần LỚN HƠN lan_nhieu thì cập nhật so_nhieu và lan_nhieu

print("Xuất hiện nhiều nhất:", so_nhieu, "(" + str(lan_nhieu), "lần)")
