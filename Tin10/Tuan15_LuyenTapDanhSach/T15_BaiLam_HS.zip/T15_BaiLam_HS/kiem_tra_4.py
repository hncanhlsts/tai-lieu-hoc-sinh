"""Tự kiểm tra Bài 4. Đặt file này CÙNG THƯ MỤC với bai_4.py rồi chạy (F5 trong Thonny/IDLE)."""
import os, re, subprocess, sys

FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bai_4.py")
DAT = 0
TONG = 0


def chay(du_lieu):
    """Chạy bai_4.py với dữ liệu nhập cho trước, trả về phần in ra màn hình."""
    kq = subprocess.run([sys.executable, FILE], input=du_lieu, capture_output=True,
                        text=True, encoding="utf-8", timeout=2,
                        env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    if kq.returncode != 0:
        dong_cuoi = kq.stderr.strip().splitlines()[-1] if kq.stderr.strip() else "lỗi"
        if "EOFError" in dong_cuoi:
            dong_cuoi = "chương trình đòi nhập nhiều hơn số lần cần thiết"
        raise RuntimeError(dong_cuoi)
    return kq.stdout


def cac_so(van_ban):
    """Các số nguyên xuất hiện trong văn bản (bỏ dấu phân cách hàng nghìn)."""
    van_ban = re.sub(r"(?<=\d)[.,_](?=\d{3}\b)", "", van_ban)
    return [int(x) for x in re.findall(r"-?\d+", van_ban)]


def kiem_tra(mo_ta, du_lieu, dieu_kien):
    global DAT, TONG
    TONG += 1
    try:
        ok = dieu_kien(chay(du_lieu))
    except subprocess.TimeoutExpired:
        print(f"  ✗ {mo_ta}  →  chạy quá 2 giây: có thể bị LẶP VÔ TẬN (biến điều kiện có được cập nhật không?)")
        return
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def ma_lenh():
    """Mã lệnh của bài làm, đã bỏ đề bài trong ba dấu nháy và các chú thích #."""
    van_ban = re.sub(r'"""[\s\S]*?"""', "", open(FILE, encoding="utf-8").read())
    return "\n".join(dong.split("#")[0] for dong in van_ban.splitlines())


print("KIỂM TRA BÀI 4")

kiem_tra("5, -2, 7, 0 → Danh sách: [5, -2, 7]", "5\n-2\n7\n0\n", lambda o: "Danh sách: [5, -2, 7]" in o)
kiem_tra("5, -2, 7, 0 → Số dương: 2 và Tổng: 10", "5\n-2\n7\n0\n", lambda o: "Số dương: 2" in o and "Tổng: 10" in o)
kiem_tra("Dừng ngay ở số 0 đầu tiên: 3, 0, 9 → [3]", "3\n0\n9\n", lambda o: "Danh sách: [3]" in o and "Tổng: 3" in o)
kiem_tra("Nhập 0 ngay từ đầu → danh sách rỗng, Tổng: 0", "0\n", lambda o: "Danh sách: []" in o and "Số dương: 0" in o and "Tổng: 0" in o)

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
