"""Bài 4 – Nhập đến khi gặp số 0 (chưa biết trước số phần tử)
Nhập lần lượt các số nguyên, mỗi lần một số; gặp số 0 thì dừng (số 0 KHÔNG đưa vào danh sách).
In "Danh sách: [...]", "Số dương: ..." (đếm số lớn hơn 0) và "Tổng: ...".
Ví dụ: 5, -2, 7, 0 → Danh sách: [5, -2, 7], Số dương: 2, Tổng: 10
Làm xong, chạy file kiem_tra_4.py để tự kiểm tra."""
ds = []
# TODO: while True: nhập x; nếu x == 0 thì break; ngược lại append x vào ds

# TODO: đếm số dương bằng vòng lặp
print("Danh sách:", ds)
