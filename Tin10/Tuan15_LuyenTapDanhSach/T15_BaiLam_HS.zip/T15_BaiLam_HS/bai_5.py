"""Bài 5 – Đảo ngược danh sách (KHÔNG dùng reverse, reversed hay ds[::-1])
Nhập n, rồi nhập n số nguyên. Tạo danh sách dao bằng cách duyệt chỉ số từ cuối về đầu.
In "Đảo ngược: [...]". Nếu dao giống ds thì in "Đối xứng", ngược lại in "Không đối xứng".
Ví dụ: 1, 2, 3 → Đảo ngược: [3, 2, 1] và Không đối xứng; 4, 7, 4 → Đảo ngược: [4, 7, 4] và Đối xứng
Làm xong, chạy file kiem_tra_5.py để tự kiểm tra."""
n = int(input("Số phần tử: "))
ds = []
for i in range(n):
    ds.append(int(input("Nhập số: ")))
dao = []
# TODO: duyệt i từ len(ds) - 1 về 0 (range với bước -1), append ds[i] vào dao

print("Đảo ngược:", dao)
# TODO: in Đối xứng hoặc Không đối xứng
