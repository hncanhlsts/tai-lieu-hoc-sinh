"""Tự kiểm tra Bài 6. Đặt file này CÙNG THƯ MỤC với bai_6.py rồi chạy (F5 trong Thonny/IDLE)."""
import os, re, subprocess, sys

FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bai_6.py")
DAT = 0
TONG = 0


def chay(du_lieu):
    """Chạy bai_6.py với dữ liệu nhập cho trước, trả về phần in ra màn hình."""
    kq = subprocess.run([sys.executable, FILE], input=du_lieu, capture_output=True,
                        text=True, encoding="utf-8", timeout=2,
                        env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    if kq.returncode != 0:
        dong_cuoi = kq.stderr.strip().splitlines()[-1] if kq.stderr.strip() else "lỗi"
        if "EOFError" in dong_cuoi:
            dong_cuoi = "chương trình đòi nhập nhiều hơn số lần cần thiết"
        raise RuntimeError(dong_cuoi)
    return kq.stdout


def cac_so(van_ban):
    """Các số nguyên xuất hiện trong văn bản (bỏ dấu phân cách hàng nghìn)."""
    van_ban = re.sub(r"(?<=\d)[.,_](?=\d{3}\b)", "", van_ban)
    return [int(x) for x in re.findall(r"-?\d+", van_ban)]


def kiem_tra(mo_ta, du_lieu, dieu_kien):
    global DAT, TONG
    TONG += 1
    try:
        ok = dieu_kien(chay(du_lieu))
    except subprocess.TimeoutExpired:
        print(f"  ✗ {mo_ta}  →  chạy quá 2 giây: có thể bị LẶP VÔ TẬN (biến điều kiện có được cập nhật không?)")
        return
    except Exception as e:  # noqa
        print(f"  ✗ {mo_ta}  →  lỗi: {e}")
        return
    if ok:
        DAT += 1
        print(f"  ✓ {mo_ta}")
    else:
        print(f"  ✗ {mo_ta}")


def ma_lenh():
    """Mã lệnh của bài làm, đã bỏ đề bài trong ba dấu nháy và các chú thích #."""
    van_ban = re.sub(r'"""[\s\S]*?"""', "", open(FILE, encoding="utf-8").read())
    return "\n".join(dong.split("#")[0] for dong in van_ban.splitlines())


print("KIỂM TRA BÀI 6")

kiem_tra("5, 3, 7, 3, 5, 3 → 3 (3 lần)", "6\n5\n3\n7\n3\n5\n3\n", lambda o: cac_so(o.strip().splitlines()[-1]) == [3, 3])
kiem_tra("Hòa số lần: 4, 9, 9, 4 → lấy 4 (xuất hiện trước)", "4\n4\n9\n9\n4\n", lambda o: cac_so(o.strip().splitlines()[-1]) == [4, 2])
kiem_tra("Không có số lặp: 1, 2, 3 → 1 (1 lần)", "3\n1\n2\n3\n", lambda o: cac_so(o.strip().splitlines()[-1]) == [1, 1])
kiem_tra("Không dùng ds.count", "2\n8\n8\n",
         lambda o: ".count(" not in ma_lenh() and cac_so(o.strip().splitlines()[-1]) == [8, 2])

print(f"\nKết quả: {DAT}/{TONG} kiểm tra đạt" + ("  🎉" if DAT == TONG else ""))
