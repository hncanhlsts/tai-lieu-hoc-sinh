"""Bài 2 – Cộng điểm thưởng (SỬA TẠI CHỖ theo chỉ số)
Nhập n, rồi nhập n điểm (số nguyên). Cộng thêm 1 điểm cho MỖI bạn nhưng điểm tối đa là 10.
Sửa ngay trong danh sách ds (không tạo danh sách mới), rồi in "Sau khi cộng: [...]".
Ví dụ: 7, 9, 10, 5 → Sau khi cộng: [8, 10, 10, 6]
Làm xong, chạy file kiem_tra_2.py để tự kiểm tra."""
n = int(input("Số phần tử: "))
ds = []
for i in range(n):
    ds.append(int(input("Nhập điểm: ")))
# TODO: duyệt theo CHỈ SỐ i; cộng 1 vào ds[i]; nếu vượt 10 thì gán lại bằng 10

print("Sau khi cộng:", ds)
