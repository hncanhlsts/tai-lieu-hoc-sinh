"""Bài 3 – Những số trên trung bình (TẠO DANH SÁCH MỚI)
Nhập n, rồi nhập n số nguyên. Tính trung bình cộng, tạo danh sách tren_tb gồm các số
LỚN HƠN trung bình (giữ thứ tự). In "Trên trung bình: [...]" và "Có k số".
Ví dụ: 4, 8, 9, 3 (trung bình 6.0) → Trên trung bình: [8, 9] và Có 2 số
Làm xong, chạy file kiem_tra_3.py để tự kiểm tra."""
n = int(input("Số phần tử: "))
ds = []
for i in range(n):
    ds.append(int(input("Nhập số: ")))
tb = sum(ds) / len(ds)
tren_tb = []
# TODO: duyệt ds; số nào lớn hơn tb thì append vào tren_tb

print("Trên trung bình:", tren_tb)
print("Có", len(tren_tb), "số")
