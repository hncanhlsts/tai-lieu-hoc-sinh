"""Bài 1 – Thống kê nhiệt độ (DÙNG hàm có sẵn sum, max, min, len)
Nhập n, rồi nhập n nhiệt độ (số nguyên). In ra:
Cao nhất: ..., Thấp nhất: ..., Chênh lệch: ... (cao nhất trừ thấp nhất),
Trung bình: ... (làm tròn 1 chữ số thập phân bằng round).
Ví dụ: 30, 32, 34, 29, 27, 31, 30 → Cao nhất: 34, Thấp nhất: 27, Chênh lệch: 7, Trung bình: 30.4
Làm xong, chạy file kiem_tra_1.py để tự kiểm tra."""
n = int(input("Số phần tử: "))
ds = []
for i in range(n):
    ds.append(int(input("Nhập số: ")))
# TODO: dùng max, min, sum, len để tính rồi in 4 dòng kết quả
